
export enum Language {
  EN = 'en',
  AR = 'ar'
}

export type View = 'dashboard' | 'encrypt' | 'decrypt' | 'settings' | 'onboarding' | 'about';

export interface AppState {
  language: Language;
  theme: 'light' | 'dark';
  onboarded: boolean;
  currentView: View;
}

export interface EncryptionData {
  carrier: File | null;
  secret: File | null;
  password: string;
  output: string | null;
  status: 'idle' | 'processing' | 'success' | 'error';
  progress: number;
}

export interface DecryptionData {
  encodedImage: File | null;
  password: string;
  extractedFile: {
    name: string;
    blob: Blob;
    url: string;
  } | null;
  status: 'idle' | 'processing' | 'success' | 'error';
  progress: number;
}
