
/**
 * Mida Steganography Engine (Pro Version)
 * LSB + Simple XOR Encryption with Password
 */

const SIGNATURE = "MIDA_P";

// Simple XOR encryption for basic password protection in demo
function xorBytes(data: Uint8Array, key: string): Uint8Array {
  const keyBytes = new TextEncoder().encode(key);
  const result = new Uint8Array(data.length);
  for (let i = 0; i < data.length; i++) {
    result[i] = data[i] ^ keyBytes[i % keyBytes.length];
  }
  return result;
}

export async function hideFileInImage(
  carrier: File,
  secret: File,
  password: string,
  onProgress: (p: number) => void
): Promise<Blob> {
  return new Promise(async (resolve, reject) => {
    try {
      const img = new Image();
      img.src = URL.createObjectURL(carrier);
      await new Promise((res) => (img.onload = res));

      const canvas = document.createElement('canvas');
      canvas.width = img.width;
      canvas.height = img.height;
      const ctx = canvas.getContext('2d');
      if (!ctx) throw new Error("Context failed");

      ctx.drawImage(img, 0, 0);
      const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
      const data = imageData.data;

      const secretBuffer = await secret.arrayBuffer();
      let secretBytes = new Uint8Array(secretBuffer);
      
      // Encrypt file bytes with password
      secretBytes = xorBytes(secretBytes, password);

      const fileNameBytes = new TextEncoder().encode(secret.name);
      // Encrypt file name bytes too
      const encryptedFileNameBytes = xorBytes(fileNameBytes, password);

      // Header structure: [SIGNATURE(6)] [NameLen(1)] [Name(N)] [DataLen(4)] [Data]
      const header = new Uint8Array(6 + 1 + encryptedFileNameBytes.length + 4);
      header.set(new TextEncoder().encode(SIGNATURE), 0);
      header.set([encryptedFileNameBytes.length], 6);
      header.set(encryptedFileNameBytes, 7);
      
      const dataView = new DataView(header.buffer);
      dataView.setUint32(7 + encryptedFileNameBytes.length, secretBytes.length, false);

      const totalBytes = header.length + secretBytes.length;
      if ((totalBytes * 8) > data.length * 0.75) throw new Error("Image too small");

      const allData = new Uint8Array(totalBytes);
      allData.set(header, 0);
      allData.set(secretBytes, header.length);

      let bitIdx = 0;
      for (let i = 0; i < allData.length; i++) {
        const byte = allData[i];
        for (let bit = 7; bit >= 0; bit--) {
          const bitVal = (byte >> bit) & 1;
          const pixelIdx = Math.floor(bitIdx / 3) * 4 + (bitIdx % 3);
          data[pixelIdx] = (data[pixelIdx] & 0xFE) | bitVal;
          bitIdx++;
        }
        if (i % 50 === 0) onProgress(Math.floor((i / allData.length) * 100));
      }

      ctx.putImageData(imageData, 0, 0);
      canvas.toBlob((b) => b ? resolve(b) : reject("Blob fail"), 'image/png');
    } catch (err) { reject(err); }
  });
}

export async function extractFileFromImage(
  encodedImage: File,
  password: string,
  onProgress: (p: number) => void
): Promise<{ name: string; blob: Blob }> {
  return new Promise(async (resolve, reject) => {
    try {
      const img = new Image();
      img.src = URL.createObjectURL(encodedImage);
      await new Promise((res) => (img.onload = res));

      const canvas = document.createElement('canvas');
      canvas.width = img.width;
      canvas.height = img.height;
      const ctx = canvas.getContext('2d');
      if (!ctx) throw new Error("Context failed");

      ctx.drawImage(img, 0, 0);
      const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
      const data = imageData.data;

      const extractBits = (count: number, startBit: number): Uint8Array => {
        const bytes = new Uint8Array(count);
        let cur = startBit;
        for (let i = 0; i < count; i++) {
          let b = 0;
          for (let bit = 7; bit >= 0; bit--) {
            const idx = Math.floor(cur / 3) * 4 + (cur % 3);
            b |= ((data[idx] & 1) << bit);
            cur++;
          }
          bytes[i] = b;
        }
        return bytes;
      };

      const sigBytes = extractBits(6, 0);
      if (new TextDecoder().decode(sigBytes) !== SIGNATURE) throw new Error("No Mida data");

      const nameLen = extractBits(1, 6 * 8)[0];
      const encryptedName = extractBits(nameLen, 7 * 8);
      const fileName = new TextDecoder().decode(xorBytes(encryptedName, password));

      const dataLenBytes = extractBits(4, (7 + nameLen) * 8);
      const dataLen = new DataView(dataLenBytes.buffer).getUint32(0, false);

      const encryptedData = extractBits(dataLen, (7 + nameLen + 4) * 8);
      const decryptedData = xorBytes(encryptedData, password);

      resolve({
        name: fileName,
        blob: new Blob([decryptedData])
      });
    } catch (err) { reject("Invalid password or corrupted image."); }
  });
}
