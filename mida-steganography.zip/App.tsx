
import React, { useState, useEffect } from 'react';
import { Language, View, AppState, EncryptionData, DecryptionData } from './types';
import { translations } from './translations';
import Onboarding from './components/Onboarding';
import AdPlaceholder from './components/AdPlaceholder';
import { hideFileInImage, extractFileFromImage } from './services/steganography';

const DashboardIcon = () => <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6" /></svg>;
const EncryptIcon = () => <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" /></svg>;
const DecryptIcon = () => <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 11V7a4 4 0 118 0m-4 8v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2z" /></svg>;
const SettingsIcon = () => <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z" /><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" /></svg>;
const AboutIcon = () => <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>;

const App: React.FC = () => {
  const [appState, setAppState] = useState<AppState>(() => {
    const saved = localStorage.getItem('mida_state_v3');
    return saved ? JSON.parse(saved) : {
      language: Language.EN,
      theme: 'light',
      onboarded: false,
      currentView: 'dashboard',
    };
  });

  const initialEncryption: EncryptionData = {
    carrier: null, secret: null, password: '', output: null, status: 'idle', progress: 0
  };

  const initialDecryption: DecryptionData = {
    encodedImage: null, password: '', extractedFile: null, status: 'idle', progress: 0
  };

  const [encryption, setEncryption] = useState<EncryptionData>(initialEncryption);
  const [decryption, setDecryption] = useState<DecryptionData>(initialDecryption);

  useEffect(() => {
    localStorage.setItem('mida_state_v3', JSON.stringify(appState));
    const isDark = appState.theme === 'dark';
    document.documentElement.classList.toggle('dark', isDark);
    document.body.className = isDark ? 'bg-slate-900 text-white' : 'bg-gray-50 text-gray-900';
  }, [appState]);

  const t = translations[appState.language];

  const validatePassword = (pw: string) => {
    const regex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d).+$/;
    return regex.test(pw);
  };

  const resetAll = () => {
    setEncryption(initialEncryption);
    setDecryption(initialDecryption);
    setAppState(p => ({ ...p, currentView: 'dashboard' }));
  };

  const handleStartEncryption = async () => {
    if (!encryption.carrier || !encryption.secret) return alert(t.noCarrier);
    if (!validatePassword(encryption.password)) return alert(t.passwordError);

    setEncryption(p => ({ ...p, status: 'processing', progress: 0 }));
    try {
      const res = await hideFileInImage(encryption.carrier!, encryption.secret!, encryption.password, (p) => {
        setEncryption(prev => ({ ...prev, progress: p }));
      });
      setEncryption(p => ({ ...p, status: 'success', output: URL.createObjectURL(res), progress: 100 }));
    } catch (e: any) {
      alert(e.message || t.error);
      setEncryption(p => ({ ...p, status: 'error' }));
    }
  };

  const handleStartDecryption = async () => {
    if (!decryption.encodedImage) return alert(t.noEncoded);
    if (!decryption.password) return alert(t.enterPassword);

    setDecryption(p => ({ ...p, status: 'processing', progress: 0 }));
    try {
      const res = await extractFileFromImage(decryption.encodedImage!, decryption.password, (p) => {
        setDecryption(prev => ({ ...prev, progress: p }));
      });
      setDecryption(p => ({
        ...p, status: 'success', progress: 100,
        extractedFile: { name: res.name, blob: res.blob, url: URL.createObjectURL(res.blob) }
      }));
    } catch (e: any) {
      alert(t.wrongPassword);
      setDecryption(p => ({ ...p, status: 'error' }));
    }
  };

  const handleDownloadAndReset = () => {
    setTimeout(resetAll, 800);
  };

  if (!appState.onboarded) return <Onboarding language={appState.language} onComplete={() => setAppState(p => ({ ...p, onboarded: true }))} />;

  const isRtl = appState.language === Language.AR;

  return (
    <div className={`min-h-screen flex flex-col transition-colors duration-300 ${isRtl ? 'rtl text-right' : 'text-left'}`}>
      {/* Header */}
      <header className={`px-6 py-4 flex items-center justify-between sticky top-0 z-30 border-b ${appState.theme === 'dark' ? 'bg-slate-800 border-slate-700' : 'bg-white border-gray-100'}`}>
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-indigo-600 rounded-xl flex items-center justify-center shadow-indigo-500/20 shadow-lg">
            <span className="text-white font-black text-xl italic">M</span>
          </div>
          <h1 className="text-lg font-bold">{t.appName}</h1>
        </div>
        <button onClick={() => setAppState(p => ({ ...p, currentView: 'settings' }))} className="p-2 rounded-full hover:bg-gray-100 dark:hover:bg-slate-700 transition-colors">
          <SettingsIcon />
        </button>
      </header>

      {/* Main Content Area */}
      <main className="flex-1 p-6 pb-28 max-w-2xl mx-auto w-full space-y-6">
        {appState.currentView === 'dashboard' && (
          <div className="space-y-6 animate-in slide-in-from-bottom-2 duration-500">
            <div className="bg-gradient-to-br from-indigo-600 to-indigo-800 rounded-3xl p-8 text-white shadow-2xl relative overflow-hidden">
               <div className="relative z-10">
                <h2 className="text-2xl font-bold mb-2">{t.welcome}</h2>
                <p className="opacity-80 text-sm leading-relaxed">{t.onboardingDesc}</p>
               </div>
               <div className="absolute -right-10 -top-10 w-40 h-40 bg-white opacity-5 rounded-full blur-3xl"></div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <Card 
                title={t.encrypt} icon={<EncryptIcon />} theme={appState.theme} 
                onClick={() => setAppState(p => ({ ...p, currentView: 'encrypt' }))} 
              />
              <Card 
                title={t.decrypt} icon={<DecryptIcon />} theme={appState.theme} 
                onClick={() => setAppState(p => ({ ...p, currentView: 'decrypt' }))} 
              />
            </div>
            
            <div className={`p-6 rounded-3xl border ${appState.theme === 'dark' ? 'bg-slate-800/50 border-slate-700' : 'bg-white border-gray-100 shadow-sm'}`}>
               <h3 className="font-bold text-indigo-600 mb-2 flex items-center gap-2">
                 <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M13 10V3L4 14h7v7l9-11h-7z" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/></svg>
                 {t.training}
               </h3>
               <p className="text-xs text-gray-500 leading-relaxed">{t.specializationDesc}</p>
            </div>
          </div>
        )}

        {appState.currentView === 'encrypt' && (
          <div className="space-y-6 animate-in fade-in">
            <h2 className="text-2xl font-bold flex items-center gap-2">
              <span className="w-8 h-8 bg-indigo-100 dark:bg-indigo-900/30 text-indigo-600 rounded-lg flex items-center justify-center"><EncryptIcon /></span>
              {t.encryptionTitle}
            </h2>
            <UploadZone label={t.step1} file={encryption.carrier} onSelect={f => setEncryption(p => ({ ...p, carrier: f }))} theme={appState.theme} accept="image/*" />
            <UploadZone label={t.step2} file={encryption.secret} onSelect={f => setEncryption(p => ({ ...p, secret: f }))} theme={appState.theme} />
            <div className={`p-4 rounded-2xl border ${appState.theme === 'dark' ? 'bg-slate-800 border-slate-700' : 'bg-white border-gray-100'}`}>
              <label className="text-xs font-bold uppercase text-gray-400 mb-2 block">{t.step3}</label>
              <input type="password" placeholder={t.enterPassword} value={encryption.password} onChange={e => setEncryption(p => ({ ...p, password: e.target.value }))} className={`w-full p-4 rounded-xl border focus:ring-2 focus:ring-indigo-500 outline-none transition-all ${appState.theme === 'dark' ? 'bg-slate-900 border-slate-700 text-white' : 'bg-gray-50 border-gray-200'}`} />
              <p className="mt-2 text-[10px] text-gray-500">{t.passwordHint}</p>
            </div>
            {encryption.status === 'processing' ? <Progress value={encryption.progress} text={t.processing} /> : encryption.status === 'success' ? (
              <a href={encryption.output!} download="mida_vault.png" onClick={handleDownloadAndReset} className="w-full bg-green-500 py-4 rounded-2xl text-white font-bold flex items-center justify-center gap-2 shadow-lg shadow-green-500/20">
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M4 16v1a2 2 0 002 2h12a2 2 0 002-2v-1m-4-4l-4 4m0 0l-4-4m4 4V4" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/></svg>
                {t.downloadResult}
              </a>
            ) : <button onClick={handleStartEncryption} className="w-full bg-indigo-600 hover:bg-indigo-700 py-4 rounded-2xl text-white font-bold shadow-xl shadow-indigo-600/20 active:scale-95 transition-all">{t.startEncryption}</button>}
          </div>
        )}

        {appState.currentView === 'decrypt' && (
          <div className="space-y-6 animate-in fade-in">
            <h2 className="text-2xl font-bold flex items-center gap-2">
              <span className="w-8 h-8 bg-indigo-100 dark:bg-indigo-900/30 text-indigo-600 rounded-lg flex items-center justify-center"><DecryptIcon /></span>
              {t.decryptionTitle}
            </h2>
            <UploadZone label={t.selectEncoded} file={decryption.encodedImage} onSelect={f => setDecryption(p => ({ ...p, encodedImage: f }))} theme={appState.theme} accept="image/*" />
            <div className={`p-4 rounded-2xl border ${appState.theme === 'dark' ? 'bg-slate-800 border-slate-700' : 'bg-white border-gray-100'}`}>
              <label className="text-xs font-bold uppercase text-gray-400 mb-2 block">{t.enterPassword}</label>
              <input type="password" placeholder="••••••••••••" value={decryption.password} onChange={e => setDecryption(p => ({ ...p, password: e.target.value }))} className={`w-full p-4 rounded-xl border focus:ring-2 focus:ring-indigo-500 outline-none transition-all ${appState.theme === 'dark' ? 'bg-slate-900 border-slate-700 text-white' : 'bg-gray-50 border-gray-200'}`} />
            </div>
            {decryption.status === 'processing' ? <Progress value={decryption.progress} text={t.processing} /> : decryption.status === 'success' ? (
              <div className="bg-green-500/10 border border-green-500/20 p-6 rounded-3xl flex flex-col items-center gap-4 text-center">
                <div className="w-16 h-16 bg-green-500 text-white rounded-full flex items-center justify-center shadow-lg"><svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M5 13l4 4L19 7" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"/></svg></div>
                <p className="font-bold text-green-600">{decryption.extractedFile?.name}</p>
                <a href={decryption.extractedFile?.url} download={decryption.extractedFile?.name} onClick={handleDownloadAndReset} className="bg-green-600 px-8 py-3 rounded-xl text-white font-bold">{t.downloadResult}</a>
              </div>
            ) : <button onClick={handleStartDecryption} className="w-full bg-indigo-600 hover:bg-indigo-700 py-4 rounded-2xl text-white font-bold shadow-xl shadow-indigo-600/20 transition-all">{t.extractFile}</button>}
          </div>
        )}

        {appState.currentView === 'about' && (
          <div className="space-y-6 animate-in fade-in">
            <h2 className="text-2xl font-bold">{t.about}</h2>
            <div className={`p-8 rounded-3xl border ${appState.theme === 'dark' ? 'bg-slate-800 border-slate-700' : 'bg-white border-gray-100 shadow-sm'} space-y-6`}>
              <div>
                <h3 className="text-xl font-bold text-indigo-600 mb-2">{t.aboutTitle}</h3>
                <p className="text-sm text-gray-500 leading-relaxed">{t.aboutDesc}</p>
              </div>
              
              <div className="flex gap-4">
                <div className="w-12 h-12 bg-indigo-100 dark:bg-indigo-900/30 text-indigo-600 rounded-xl flex items-center justify-center shrink-0">
                  <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M12 14l9-5-9-5-9 5 9 5z" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/></svg>
                </div>
                <div>
                  <h4 className="font-bold text-sm uppercase tracking-wider mb-1">{t.specialization}</h4>
                  <p className="text-xs text-gray-500 leading-relaxed">{t.specializationDesc}</p>
                </div>
              </div>

              <div className="pt-6 border-t border-gray-100 dark:border-slate-700">
                <h3 className="font-bold mb-3 flex items-center gap-2">
                  <svg className="w-5 h-5 text-indigo-600" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/></svg>
                  {t.contactUs}
                </h3>
                <p className="text-sm font-medium text-indigo-600 underline cursor-pointer">{t.email}</p>
              </div>
            </div>
          </div>
        )}

        {appState.currentView === 'settings' && (
          <div className="space-y-6 animate-in fade-in">
            <h2 className="text-2xl font-bold">{t.settings}</h2>
            <div className={`rounded-3xl border divide-y ${appState.theme === 'dark' ? 'bg-slate-800 border-slate-700 divide-slate-700' : 'bg-white border-gray-100 divide-gray-100'}`}>
              <div className="p-6 flex items-center justify-between">
                <div><p className="font-bold">{t.language}</p><p className="text-xs text-gray-500">{t.selectLanguage}</p></div>
                <div className="flex bg-gray-100 dark:bg-slate-900 p-1 rounded-xl">
                  {Object.values(Language).map(l => (
                    <button key={l} onClick={() => setAppState(p => ({ ...p, language: l }))} className={`px-4 py-1.5 rounded-lg text-sm font-bold transition-all ${appState.language === l ? 'bg-white dark:bg-indigo-600 shadow-sm text-indigo-600 dark:text-white' : 'text-gray-400'}`}>{l.toUpperCase()}</button>
                  ))}
                </div>
              </div>
              <div className="p-6 flex items-center justify-between">
                <div><p className="font-bold">{t.darkMode}</p></div>
                <button onClick={() => setAppState(p => ({ ...p, theme: p.theme === 'light' ? 'dark' : 'light' }))} className={`w-14 h-8 rounded-full relative transition-colors ${appState.theme === 'dark' ? 'bg-indigo-600' : 'bg-gray-200'}`}><div className={`absolute top-1 w-6 h-6 bg-white rounded-full transition-all shadow-md ${appState.theme === 'dark' ? 'left-7' : 'left-1'}`}></div></button>
              </div>
              <div className="p-6 text-center text-gray-400 italic text-xs">Mida v1.0.0</div>
            </div>
          </div>
        )}
      </main>

      {/* Ad Space */}
      <div className="fixed bottom-16 left-0 right-0 z-20 px-4">
        <AdPlaceholder type="banner" language={appState.language} />
      </div>

      {/* Navigation - Hidden Encrypt/Decrypt Tabs */}
      <nav className={`fixed bottom-0 left-0 right-0 border-t flex items-center justify-around py-3 px-8 shadow-[0_-10px_40px_rgba(0,0,0,0.1)] z-40 backdrop-blur-xl ${appState.theme === 'dark' ? 'bg-slate-800/80 border-slate-700' : 'bg-white/80 border-gray-100'}`}>
        <NavBtn active={appState.currentView === 'dashboard'} icon={<DashboardIcon />} onClick={() => setAppState(p => ({ ...p, currentView: 'dashboard' }))} />
        <NavBtn active={appState.currentView === 'about'} icon={<AboutIcon />} onClick={() => setAppState(p => ({ ...p, currentView: 'about' }))} />
        <NavBtn active={appState.currentView === 'settings'} icon={<SettingsIcon />} onClick={() => setAppState(p => ({ ...p, currentView: 'settings' }))} />
      </nav>
    </div>
  );
};

const Card = ({ title, icon, theme, onClick }: any) => (
  <button onClick={onClick} className={`p-6 rounded-3xl border flex flex-col items-center gap-4 transition-all hover:scale-105 active:scale-95 shadow-sm hover:shadow-xl ${theme === 'dark' ? 'bg-slate-800 border-slate-700' : 'bg-white border-gray-100'}`}>
    <div className="w-14 h-14 bg-indigo-600 text-white rounded-2xl flex items-center justify-center shadow-lg shadow-indigo-600/30">{icon}</div>
    <span className="font-bold text-sm">{title}</span>
  </button>
);

const UploadZone = ({ label, file, onSelect, theme, accept }: any) => (
  <div className={`p-5 rounded-2xl border ${theme === 'dark' ? 'bg-slate-800 border-slate-700' : 'bg-white border-gray-100 shadow-sm'}`}>
    <label className="text-xs font-bold uppercase text-gray-400 mb-3 block">{label}</label>
    <label className={`flex flex-col items-center justify-center w-full h-32 border-2 border-dashed rounded-2xl cursor-pointer hover:border-indigo-500 transition-colors ${theme === 'dark' ? 'border-slate-600 bg-slate-900/50' : 'border-gray-200 bg-gray-50/50'}`}>
      {file ? <div className="text-center font-bold text-indigo-500 overflow-hidden text-ellipsis whitespace-nowrap max-w-[200px]">{file.name}</div> : <div className="text-gray-400 text-sm italic">Tap to select</div>}
      <input type="file" accept={accept} className="hidden" onChange={e => onSelect(e.target.files?.[0])} />
    </label>
  </div>
);

const NavBtn = ({ active, icon, onClick }: any) => (
  <button onClick={onClick} className={`p-3 rounded-2xl transition-all ${active ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-600/40 -translate-y-2 scale-110' : 'text-gray-400 hover:text-indigo-400'}`}>
    {icon}
  </button>
);

const Progress = ({ value, text }: any) => (
  <div className="space-y-2 animate-pulse">
    <div className="w-full bg-gray-200 dark:bg-slate-700 h-2 rounded-full overflow-hidden">
      <div className="bg-indigo-600 h-full transition-all duration-300" style={{ width: `${value}%` }}></div>
    </div>
    <p className="text-center text-[10px] font-bold uppercase tracking-widest text-gray-500">{text} {value}%</p>
  </div>
);

export default App;
