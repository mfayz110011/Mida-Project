
import React from 'react';
import { translations } from '../translations';
import { Language } from '../types';

interface AdPlaceholderProps {
  type: 'banner' | 'interstitial';
  language: Language;
}

const AdPlaceholder: React.FC<AdPlaceholderProps> = ({ type, language }) => {
  const t = translations[language];

  if (type === 'interstitial') return null;

  return (
    <div className="w-full h-14 bg-white dark:bg-slate-800 border-x border-t dark:border-slate-700 rounded-t-xl flex items-center justify-between px-4 shadow-[0_-5px_15px_rgba(0,0,0,0.05)] overflow-hidden">
      <div className="flex items-center gap-2">
        <span className="bg-amber-500 text-white px-1.5 py-0.5 rounded text-[8px] font-black">AD</span>
        <div className="flex flex-col">
          <span className="text-[10px] font-bold dark:text-gray-300">Premium VPN Proxy</span>
          <span className="text-[8px] text-gray-400">Sponsored by NetworkX</span>
        </div>
      </div>
      <button className="bg-indigo-600 text-white text-[10px] px-3 py-1.5 rounded-lg font-bold shadow-sm">
        Install
      </button>
    </div>
  );
};

export default AdPlaceholder;
