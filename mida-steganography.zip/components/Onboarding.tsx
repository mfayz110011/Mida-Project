
import React from 'react';
import { translations } from '../translations';
import { Language } from '../types';

interface OnboardingProps {
  language: Language;
  onComplete: () => void;
}

const Onboarding: React.FC<OnboardingProps> = ({ language, onComplete }) => {
  const t = translations[language];

  return (
    <div className="fixed inset-0 z-50 bg-white flex flex-col items-center justify-center p-8 text-center">
      <div className="w-24 h-24 bg-indigo-600 rounded-3xl flex items-center justify-center shadow-2xl mb-8 transform rotate-12">
        <span className="text-white text-4xl font-bold tracking-tighter">M</span>
      </div>
      <h1 className="text-4xl font-bold text-gray-900 mb-4">{t.welcome}</h1>
      <p className="text-lg text-gray-600 max-w-sm mb-12">
        {t.onboardingDesc}
      </p>
      
      <button
        onClick={onComplete}
        className="w-full max-w-xs bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-4 rounded-2xl shadow-lg transition-all active:scale-95"
      >
        {t.getStarted}
      </button>

      <div className="mt-8 flex gap-2">
        <div className="w-8 h-1.5 bg-indigo-600 rounded-full"></div>
        <div className="w-2 h-1.5 bg-gray-200 rounded-full"></div>
        <div className="w-2 h-1.5 bg-gray-200 rounded-full"></div>
      </div>
    </div>
  );
};

export default Onboarding;
