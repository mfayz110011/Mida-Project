
import React, { useState } from 'react';
import { TranslationStrings } from '../types';
import { validatePassword, encryptData } from '../utils/crypto';
import { hideDataInImage } from '../utils/stega';
import AdMobPlaceholder from './AdMobPlaceholder';

interface Props {
  t: TranslationStrings;
  onBack: () => void;
}

const EncryptionView: React.FC<Props> = ({ t, onBack }) => {
  const [carrier, setCarrier] = useState<File | null>(null);
  const [secret, setSecret] = useState<File | null>(null);
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [loadingStatus, setLoadingStatus] = useState('');
  const [resultUrl, setResultUrl] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [isDone, setIsDone] = useState(false);

  const handleProcess = async () => {
    setError(null);
    if (!carrier) return setError(t.errorNoImage);
    if (!secret) return setError(t.errorNoFile);
    
    // التحقق الصارم: 8 أحرف، كبير، صغير، رقم
    if (!validatePassword(password)) {
      return setError(t.errorInvalidPassword);
    }

    try {
      setLoading(true);
      setLoadingStatus("جاري معالجة الملف...");
      
      const reader = new FileReader();
      reader.onload = async () => {
        try {
          const fileData = new Uint8Array(reader.result as ArrayBuffer);
          setLoadingStatus("تشفير البيانات (AES-256)...");
          const encrypted = await encryptData(fileData, password);
          
          setLoadingStatus("دمج البيانات داخل الصورة...");
          const encodedUrl = await hideDataInImage(carrier, encrypted, {
            name: secret.name,
            type: secret.type
          });
          
          setResultUrl(encodedUrl);
          setLoading(false);
        } catch (e: any) {
          setError("خطأ في المعالجة: " + e.message);
          setLoading(false);
        }
      };
      reader.readAsArrayBuffer(secret);
    } catch (e: any) {
      setError("حدث خطأ غير متوقع.");
      setLoading(false);
    }
  };

  const handleDownload = () => {
    setIsDone(true);
    // تحويل تلقائي بعد التحميل بـ 2 ثانية لراحة المستخدم
    setTimeout(() => {
      onBack();
    }, 2000);
  };

  return (
    <div className="flex flex-col min-h-screen p-6 max-w-lg mx-auto bg-white dark:bg-slate-900 transition-colors">
      {loading && (
        <div className="fixed inset-0 z-50 flex flex-col items-center justify-center bg-white/90 dark:bg-slate-900/90 backdrop-blur-md">
          <div className="w-16 h-16 border-4 border-indigo-600 border-t-transparent rounded-full animate-spin mb-4"></div>
          <p className="text-xl font-bold text-indigo-600 dark:text-indigo-400 text-center px-6">{loadingStatus}</p>
        </div>
      )}

      <div className="flex items-center mb-8">
        <button onClick={onBack} className="p-2 rounded-full hover:bg-gray-100 dark:hover:bg-slate-800 transition-colors">
          <i className="fa-solid fa-arrow-left text-xl dark:text-white rtl:rotate-180"></i>
        </button>
        <h2 className="text-2xl font-black ml-4 rtl:mr-4 rtl:ml-0 dark:text-white">{t.encrypt}</h2>
      </div>

      <div className="space-y-6 flex-grow">
        <div className="space-y-2">
          <label className="block text-sm font-bold text-gray-700 dark:text-slate-300">{t.carrierImage}</label>
          <label className="flex flex-col items-center justify-center w-full h-32 border-2 border-dashed border-indigo-200 rounded-3xl cursor-pointer hover:bg-indigo-50 dark:border-slate-700 dark:hover:bg-slate-800 transition-all group">
            <i className="fa-solid fa-image text-3xl text-indigo-400 group-hover:scale-110 transition-transform mb-2"></i>
            <span className="text-sm text-gray-500 truncate px-4 font-medium">
              {carrier ? carrier.name : t.selectImage}
            </span>
            <input type="file" className="hidden" accept="image/png,image/jpeg" onChange={e => setCarrier(e.target.files?.[0] || null)} />
          </label>
        </div>

        <div className="space-y-2">
          <label className="block text-sm font-bold text-gray-700 dark:text-slate-300">{t.secretFile}</label>
          <label className="flex flex-col items-center justify-center w-full h-32 border-2 border-dashed border-emerald-200 rounded-3xl cursor-pointer hover:bg-emerald-50 dark:border-slate-700 dark:hover:bg-slate-800 transition-all group">
            <i className="fa-solid fa-file-shield text-3xl text-emerald-400 group-hover:scale-110 transition-transform mb-2"></i>
            <span className="text-sm text-gray-500 truncate px-4 font-medium">
              {secret ? secret.name : t.selectFile}
            </span>
            <input type="file" className="hidden" onChange={e => setSecret(e.target.files?.[0] || null)} />
          </label>
        </div>

        <div className="space-y-2">
          <label className="block text-sm font-bold text-gray-700 dark:text-slate-300">{t.password}</label>
          <div className="relative">
            <input 
              type={showPassword ? "text" : "password"} 
              className="w-full px-5 py-4 rounded-2xl bg-gray-50 dark:bg-slate-800 dark:text-white border-2 border-transparent focus:border-indigo-500 outline-none transition-all font-bold"
              placeholder="••••••••"
              value={password}
              onChange={e => setPassword(e.target.value)}
            />
            <button onClick={() => setShowPassword(!showPassword)} className="absolute right-4 top-1/2 -translate-y-1/2 text-gray-400">
              <i className={`fa-solid ${showPassword ? 'fa-eye-slash' : 'fa-eye'}`}></i>
            </button>
          </div>
          <p className="text-[11px] text-indigo-500 font-bold px-2">{t.passwordHint}</p>
        </div>

        {error && (
          <div className="p-4 bg-red-50 text-red-600 rounded-2xl border border-red-200 text-sm font-bold flex items-center">
            <i className="fa-solid fa-circle-xmark mr-2"></i> {error}
          </div>
        )}

        {!resultUrl ? (
          <button onClick={handleProcess} className="w-full py-5 bg-indigo-600 text-white rounded-2xl font-black text-xl shadow-xl hover:bg-indigo-700 transition-all active:scale-95">
            {t.process}
          </button>
        ) : (
          <div className="space-y-4">
             <div className="p-4 bg-green-100 text-green-700 rounded-2xl text-center font-bold">
              {isDone ? "تم التحميل! جاري العودة..." : "تم التشفير بنجاح!"}
            </div>
            <a 
              href={resultUrl} 
              download={`mida_secure_${Date.now()}.png`} 
              onClick={handleDownload}
              className="flex items-center justify-center w-full py-5 bg-emerald-600 text-white rounded-2xl font-black text-xl shadow-xl hover:bg-emerald-700 transition-all"
            >
              <i className="fa-solid fa-download mr-2 rtl:ml-2 rtl:mr-0"></i> تحميل النتيجة
            </a>
          </div>
        )}
      </div>
      <AdMobPlaceholder />
    </div>
  );
};

export default EncryptionView;
