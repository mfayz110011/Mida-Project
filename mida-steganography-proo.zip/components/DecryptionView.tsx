
import React, { useState } from 'react';
import { TranslationStrings } from '../types';
import { decryptData } from '../utils/crypto';
import { extractDataFromImage } from '../utils/stega';
import AdMobPlaceholder from './AdMobPlaceholder';

interface Props {
  t: TranslationStrings;
  onBack: () => void;
}

const DecryptionView: React.FC<Props> = ({ t, onBack }) => {
  const [encoded, setEncoded] = useState<File | null>(null);
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [loadingStatus, setLoadingStatus] = useState('');
  const [result, setResult] = useState<{ url: string, name: string } | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [isDone, setIsDone] = useState(false);

  const handleProcess = async () => {
    setError(null);
    if (!encoded) return setError(t.errorNoImage);
    if (password.length < 8) return setError("كلمة المرور يجب أن تكون 8 أحرف على الأقل.");

    try {
      setLoading(true);
      setLoadingStatus("جاري فحص بكسلات الصورة...");
      
      const extracted = await extractDataFromImage(encoded);
      
      setLoadingStatus("جاري فك التشفير...");
      const decryptedBytes = await decryptData(extracted.data, password);
      
      const blob = new Blob([decryptedBytes], { type: extracted.type });
      const url = URL.createObjectURL(blob);
      
      setResult({ url, name: extracted.name });
      setLoading(false);
    } catch (e: any) {
      setError(e.toString().includes("كلمة المرور") ? "كلمة المرور غير صحيحة." : e.message);
      setLoading(false);
    }
  };

  const handleDownload = () => {
    setIsDone(true);
    setTimeout(() => {
      onBack();
    }, 2000);
  };

  return (
    <div className="flex flex-col min-h-screen p-6 max-w-lg mx-auto bg-white dark:bg-slate-900 transition-colors">
      {loading && (
        <div className="fixed inset-0 z-50 flex flex-col items-center justify-center bg-white/90 dark:bg-slate-900/90 backdrop-blur-md">
          <div className="w-16 h-16 border-4 border-blue-600 border-t-transparent rounded-full animate-spin mb-4"></div>
          <p className="text-xl font-bold text-blue-600 dark:text-blue-400 text-center px-6">{loadingStatus}</p>
        </div>
      )}

      <div className="flex items-center mb-8">
        <button onClick={onBack} className="p-2 rounded-full hover:bg-gray-100 dark:hover:bg-slate-800 transition-colors">
          <i className="fa-solid fa-arrow-left text-xl dark:text-white rtl:rotate-180"></i>
        </button>
        <h2 className="text-2xl font-black ml-4 rtl:mr-4 rtl:ml-0 dark:text-white">{t.decrypt}</h2>
      </div>

      <div className="space-y-6 flex-grow">
        <div className="space-y-2">
          <label className="block text-sm font-bold text-gray-700 dark:text-slate-300">الصورة التي تحتوي الملف</label>
          <label className="flex flex-col items-center justify-center w-full h-48 border-2 border-dashed border-blue-300 rounded-3xl cursor-pointer hover:bg-blue-50 dark:border-slate-700 dark:hover:bg-slate-800 transition-all group">
            <i className="fa-solid fa-magnifying-glass-chart text-4xl text-blue-500 mb-3 group-hover:scale-110 transition-transform"></i>
            <span className="text-sm text-gray-500 truncate px-4 w-full text-center font-bold">
              {encoded ? encoded.name : "اختر صورة ميدأ (PNG)"}
            </span>
            <input type="file" className="hidden" accept="image/png,image/jpeg" onChange={e => setEncoded(e.target.files?.[0] || null)} />
          </label>
        </div>

        <div className="space-y-2">
          <label className="block text-sm font-bold text-gray-700 dark:text-slate-300">{t.password}</label>
          <div className="relative">
            <input 
              type={showPassword ? "text" : "password"} 
              className="w-full px-5 py-4 rounded-2xl bg-gray-50 dark:bg-slate-800 dark:text-white border-2 border-transparent focus:border-blue-500 outline-none transition-all font-bold"
              placeholder="••••••••"
              value={password}
              onChange={e => setPassword(e.target.value)}
            />
            <button onClick={() => setShowPassword(!showPassword)} className="absolute right-4 top-1/2 -translate-y-1/2 text-gray-400">
              <i className={`fa-solid ${showPassword ? 'fa-eye-slash' : 'fa-eye'}`}></i>
            </button>
          </div>
        </div>

        {error && (
          <div className="p-4 bg-red-50 text-red-600 rounded-2xl border border-red-200 text-sm font-bold flex items-center">
            <i className="fa-solid fa-triangle-exclamation mr-2"></i> {error}
          </div>
        )}

        {!result ? (
          <button onClick={handleProcess} className="w-full py-5 bg-blue-600 text-white rounded-2xl font-black text-xl shadow-xl hover:bg-blue-700 transition-all active:scale-95">
            فك التشفير الآن
          </button>
        ) : (
          <div className="space-y-4">
            <div className="p-4 bg-green-100 text-green-700 rounded-2xl text-center font-bold">
              {isDone ? "تم الاستخراج! جاري العودة..." : "تم استخراج الملف بنجاح!"}
            </div>
            <a 
              href={result.url} 
              download={result.name} 
              onClick={handleDownload}
              className="flex items-center justify-center w-full py-5 bg-emerald-600 text-white rounded-2xl font-black text-xl shadow-xl hover:bg-emerald-700 transition-all"
            >
              <i className="fa-solid fa-file-arrow-down mr-2 rtl:ml-2 rtl:mr-0"></i> تحميل {result.name}
            </a>
          </div>
        )}
      </div>
      <AdMobPlaceholder />
    </div>
  );
};

export default DecryptionView;
