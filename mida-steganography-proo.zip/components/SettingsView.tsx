
import React from 'react';
import { TranslationStrings, Language, Theme } from '../types';

interface Props {
  t: TranslationStrings;
  language: Language;
  theme: Theme;
  onSetLanguage: (lang: Language) => void;
  onSetTheme: (theme: Theme) => void;
  onBack: () => void;
}

const SettingsView: React.FC<Props> = ({ t, language, theme, onSetLanguage, onSetTheme, onBack }) => {
  return (
    <div className="flex flex-col min-h-screen p-6 max-w-lg mx-auto bg-white dark:bg-slate-900 transition-colors">
      <div className="flex items-center mb-8">
        <button onClick={onBack} className="p-2 rounded-full hover:bg-gray-100 dark:hover:bg-slate-800">
          <i className={`fa-solid ${language === Language.AR ? 'fa-arrow-right' : 'fa-arrow-left'} text-xl dark:text-white`}></i>
        </button>
        <h2 className="text-2xl font-bold mx-4 dark:text-white">{t.settings}</h2>
      </div>

      <div className="space-y-4">
        <div className="p-4 rounded-3xl bg-gray-50 dark:bg-slate-800 flex items-center justify-between">
          <div className="flex items-center">
            <div className="w-10 h-10 rounded-full bg-indigo-100 dark:bg-indigo-900/30 flex items-center justify-center text-indigo-600 dark:text-indigo-400 mr-4">
              <i className="fa-solid fa-language text-lg"></i>
            </div>
            <span className="font-medium dark:text-white">{t.language}</span>
          </div>
          <select 
            className="bg-transparent border-none outline-none font-bold text-indigo-600 dark:text-indigo-400 text-right rtl:text-left"
            value={language}
            onChange={(e) => onSetLanguage(e.target.value as Language)}
          >
            <option value={Language.EN}>English</option>
            <option value={Language.AR}>العربية</option>
          </select>
        </div>

        <div className="p-4 rounded-3xl bg-gray-50 dark:bg-slate-800 flex items-center justify-between">
          <div className="flex items-center">
            <div className="w-10 h-10 rounded-full bg-amber-100 dark:bg-amber-900/30 flex items-center justify-center text-amber-600 dark:text-amber-400 mr-4">
              <i className={`fa-solid ${theme === Theme.DARK ? 'fa-moon' : 'fa-sun'} text-lg`}></i>
            </div>
            <span className="font-medium dark:text-white">{t.theme}</span>
          </div>
          <button 
            onClick={() => onSetTheme(theme === Theme.LIGHT ? Theme.DARK : Theme.LIGHT)}
            className="w-14 h-8 bg-gray-200 dark:bg-indigo-600 rounded-full relative transition-colors duration-300"
          >
            <div className={`absolute top-1 left-1 w-6 h-6 bg-white rounded-full shadow-md transition-transform duration-300 transform ${theme === Theme.DARK ? 'translate-x-6' : 'translate-x-0'}`}></div>
          </button>
        </div>
      </div>
    </div>
  );
};

export default SettingsView;
